@extends('master')
@section('title', 'Inicio')

@section('content')
<section>
<div class="card mcard md-11 mtop32">
    <div class="card-body">
    <h2 class="card-title">Card title</h2>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
</section>
@endsection