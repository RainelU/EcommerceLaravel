-- Cuando no se muestren las imágenes, es por el filesystems.php, en donde aparece el xampp/htdocs/{sitio}, 
eso al llevarlo a producción debe cambiarse.

-- Al llevar a producción cambiar el AppServiceProvider

-- Cambiar el DEBUG a False

