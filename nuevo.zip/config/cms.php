<?php
return [
'name' => 'Bne Computers',
'website' => 'http://localhost:8000',
'company_phone' => '22222222',
'currency' => 'CLP',
'shop_min_amount' => '1000',
'shipping_method' => '2',
'shipping_default_value' => '5000',
'shipping_amount_min' => '2000',
'to_go' => '0',
'social_facebook' => 'https://www.facebook.com/',
'social_instagram' => 'https://www.instagram.com/',
'social_twitter' => '#',
'social_youtube' => '#',
'social_whatsapp' => '#',
'products_per_page' => '100',
'products_per_page_random' => '100',
]
?>
